"""
Supabase-only connection with intelligent semantic search.
No hardcoded suburbs - uses actual database data dynamically.
"""

import httpx
from typing import Any, Dict, List, Optional
import structlog

from app.config import get_settings

logger = structlog.get_logger(__name__)


class SupabaseOnlyConnection:
    """Manages Supabase connections using direct REST API."""

    def __init__(self):
        self.settings = get_settings()
        self._http_client: Optional[httpx.Client] = None

    @property
    def http_client(self) -> httpx.Client:
        if self._http_client is None:
            self._http_client = httpx.Client(timeout=30.0)
        return self._http_client

    def _get_headers(self) -> Dict[str, str]:
        key = self.settings.supabase_service_key or self.settings.supabase_key
        return {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    def search_services_by_text(self, search_term: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Intelligent semantic search that uses multiple strategies:
        1. Location-based search (suburb, state, postcode)
        2. Service-type search (anxiety, counseling, etc.)
        3. Cost-based search (free, paid)
        4. Multi-keyword search
        5. Fallback to broad search
        """
        try:
            logger.info("=== SEARCH START ===", query=search_term, limit=limit)
            
            if not search_term or not search_term.strip():
                logger.warning("Empty search term")
                return []
            
            search_lower = search_term.lower().strip()
            words = search_lower.split()
            
            # Extract search intent
            has_location_words = any(w in search_lower for w in ['in', 'near', 'around', 'at'])
            has_service_words = any(w in search_lower for w in [
                'anxiety', 'depression', 'counseling', 'counselling', 'therapy', 
                'psychologist', 'psychiatrist', 'crisis', 'help', 'support',
                'mental health', 'stress', 'suicide', 'addiction'
            ])
            has_cost_words = any(w in search_lower for w in [
                'free', 'bulk bill', 'bulk-bill', 'medicare', 'paid', 'private'
            ])
            
            logger.info("Search intent analysis",
                       has_location=has_location_words,
                       has_service=has_service_words,
                       has_cost=has_cost_words,
                       word_count=len(words))
            
            # Strategy 1: Multi-field smart search (most common case)
            results = self._smart_multi_field_search(search_term, limit)
            
            if results:
                logger.info("✓ Smart search succeeded", count=len(results))
                return results
            
            # Strategy 2: If no results, try location-only search
            if has_location_words:
                logger.info("Trying location-focused search...")
                results = self._location_focused_search(search_term, limit)
                if results:
                    logger.info("✓ Location search succeeded", count=len(results))
                    return results
            
            # Strategy 3: Try service-type focused search
            if has_service_words:
                logger.info("Trying service-focused search...")
                results = self._service_focused_search(search_term, limit)
                if results:
                    logger.info("✓ Service search succeeded", count=len(results))
                    return results
            
            # Strategy 4: Single word searches
            if len(words) == 1:
                logger.info("Single word search...")
                results = self._single_word_search(search_term, limit)
                if results:
                    logger.info("✓ Single word search succeeded", count=len(results))
                    return results
            
            # Strategy 5: Fallback - very broad search
            logger.info("Using fallback broad search")
            results = self._broad_fallback_search(search_term, limit)
            
            logger.info("=== SEARCH COMPLETE ===", final_count=len(results))
            return results

        except Exception as e:
            logger.error("Search failed", error=str(e), exc_info=True)
            return []

    def _smart_multi_field_search(self, query: str, limit: int) -> List[Dict[str, Any]]:
        """
        Search across multiple fields intelligently.
        Searches: service_name, service_type, suburb, organisation_name, notes, target_population
        """
        try:
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            
            # Build comprehensive OR filter across all relevant fields
            pattern = f"*{query.strip()}*"
            
            params = {
                "select": "*",
                "or": (
                    f"service_name.ilike.{pattern},"
                    f"service_type.ilike.{pattern},"
                    f"suburb.ilike.{pattern},"
                    f"state.ilike.{pattern},"
                    f"organisation_name.ilike.{pattern},"
                    f"notes.ilike.{pattern},"
                    f"target_population.ilike.{pattern},"
                    f"delivery_method.ilike.{pattern},"
                    f"address.ilike.{pattern}"
                ),
                "limit": str(limit)
            }
            
            logger.info("Smart multi-field search", params=params)
            
            response = self.http_client.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error("Smart search failed", error=str(e))
            return []

    def _location_focused_search(self, query: str, limit: int) -> List[Dict[str, Any]]:
        """Focus on location fields: suburb, state, postcode, address."""
        try:
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            pattern = f"*{query.strip()}*"
            
            # Extract potential postcode
            words = query.split()
            postcode_filter = None
            for word in words:
                if word.isdigit() and 3 <= len(word) <= 4:
                    postcode_filter = f"postcode.eq.{word}"
                    break
            
            # Build location-focused OR filter
            location_filters = [
                f"suburb.ilike.{pattern}",
                f"state.ilike.{pattern}",
                f"address.ilike.{pattern}",
                f"region_name.ilike.{pattern}"
            ]
            
            if postcode_filter:
                location_filters.append(postcode_filter)
            
            params = {
                "select": "*",
                "or": ",".join(location_filters),
                "limit": str(limit)
            }
            
            response = self.http_client.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error("Location search failed", error=str(e))
            return []

    def _service_focused_search(self, query: str, limit: int) -> List[Dict[str, Any]]:
        """Focus on service-related fields: service_type, service_name, notes."""
        try:
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            pattern = f"*{query.strip()}*"
            
            params = {
                "select": "*",
                "or": (
                    f"service_type.ilike.{pattern},"
                    f"service_name.ilike.{pattern},"
                    f"notes.ilike.{pattern},"
                    f"target_population.ilike.{pattern},"
                    f"level_of_care.ilike.{pattern}"
                ),
                "limit": str(limit)
            }
            
            response = self.http_client.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error("Service search failed", error=str(e))
            return []

    def _single_word_search(self, query: str, limit: int) -> List[Dict[str, Any]]:
        """Optimized search for single-word queries (e.g., just 'Carlton' or just 'anxiety')."""
        try:
            word = query.strip().lower()
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            pattern = f"*{word}*"
            
            # For single words, prioritize exact or close matches
            params = {
                "select": "*",
                "or": (
                    f"suburb.ilike.{pattern},"
                    f"service_type.ilike.{pattern},"
                    f"service_name.ilike.{pattern},"
                    f"organisation_name.ilike.{pattern},"
                    f"state.ilike.{pattern}"
                ),
                "limit": str(limit * 2)  # Get more results to rank
            }
            
            response = self.http_client.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            results = response.json()
            
            # Rank results: exact matches first
            exact_matches = []
            partial_matches = []
            
            for result in results:
                is_exact = any([
                    result.get('suburb', '').lower() == word,
                    result.get('service_type', '').lower() == word,
                    result.get('state', '').lower() == word
                ])
                
                if is_exact:
                    exact_matches.append(result)
                else:
                    partial_matches.append(result)
            
            # Return exact matches first, then partial
            ranked_results = exact_matches + partial_matches
            return ranked_results[:limit]
            
        except Exception as e:
            logger.error("Single word search failed", error=str(e))
            return []

    def _broad_fallback_search(self, query: str, limit: int) -> List[Dict[str, Any]]:
        """Very broad search as last resort."""
        try:
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            pattern = f"*{query.strip()}*"
            
            params = {
                "select": "*",
                "or": (
                    f"service_name.ilike.{pattern},"
                    f"organisation_name.ilike.{pattern},"
                    f"suburb.ilike.{pattern},"
                    f"state.ilike.{pattern},"
                    f"service_type.ilike.{pattern},"
                    f"notes.ilike.{pattern},"
                    f"target_population.ilike.{pattern},"
                    f"address.ilike.{pattern},"
                    f"delivery_method.ilike.{pattern},"
                    f"cost.ilike.{pattern},"
                    f"referral_pathway.ilike.{pattern}"
                ),
                "limit": str(limit)
            }
            
            response = self.http_client.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error("Broad search failed", error=str(e))
            return []

    async def test_connection(self) -> Dict[str, Any]:
        """Test Supabase connection."""
        try:
            url = f"{self.settings.supabase_url}/rest/v1/staging_services"
            response = self.http_client.get(
                url, 
                headers=self._get_headers(), 
                params={"select": "id", "limit": "1"}
            )
            response.raise_for_status()
            
            return {
                "status": "connected",
                "connection_type": "supabase_rest_api_direct",
                "ready_for_queries": True,
            }
        except Exception as e:
            logger.error("Connection test failed", error=str(e))
            return {"status": "error", "error": str(e)}

    def close(self):
        if self._http_client:
            self._http_client.close()


supabase_db = SupabaseOnlyConnection()

async def get_supabase_db() -> SupabaseOnlyConnection:
    return supabase_db
