from fastapi import FastAPI

app = FastAPI(title="Mental Health LLM Backend - Test")

@app.get("/")
async def root():
    return {
        "status": "healthy",
        "message": "FastAPI is running on Elastic Beanstalk!",
        "test": True
    }

@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "mental-health-llm"}
