"""
Main chat service orchestrating mental health chatbot functionality.
Returns properly structured, formatted responses.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
import structlog

from core.database.supabase_only import get_supabase_db
from core.llm.openai_client import get_openai_client
from app.config import get_settings

logger = structlog.get_logger(__name__)

class MentalHealthChatService:
    """Main service for handling mental health chatbot conversations."""

    def __init__(self):
        self.settings = get_settings()

    def _format_services(self, services: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, str]]:
        """Format services into a clean, structured list."""
        formatted = []
        for service in services[:limit]:
            formatted.append({
                "name": service.get('service_name', 'N/A'),
                "organization": service.get('organisation_name', 'N/A'),
                "location": f"{service.get('suburb', 'N/A')}, {service.get('state', 'N/A')}",
                "cost": service.get('cost', 'N/A'),
                "phone": service.get('phone', 'N/A'),
                "delivery_method": service.get('delivery_method', 'N/A'),
                "wait_time": service.get('expected_wait_time', 'Not specified'),
                "website": service.get('website', None),
                "email": service.get('email', None)
            })
        return formatted

    async def process_message(self, message: str, session_id: Optional[str] = None, user_context: Optional[Dict] = None) -> Dict[str, Any]:
        """Process a user message and return a well-formatted response."""
        try:
            if not session_id:
                session_id = str(uuid.uuid4())

            logger.info("=== CHAT SERVICE START ===", message=message, session_id=session_id)

            # Validate configuration
            if not self.settings.openai_api_key:
                logger.error("OpenAI API key not configured")
                return self._error_response(session_id, "OpenAI API key is missing")
            
            if not self.settings.supabase_url or not self.settings.supabase_key:
                logger.error("Supabase not configured")
                return self._error_response(session_id, "Supabase is not configured")

            # Get clients
            try:
                logger.info("Initializing clients...")
                openai_client = get_openai_client()
                supabase_db = await get_supabase_db()
                logger.info("✓ Clients initialized successfully")
            except Exception as e:
                logger.error("Failed to initialize clients", error=str(e), exc_info=True)
                return self._error_response(session_id, f"Client initialization failed: {str(e)}")

            # Search for services
            try:
                logger.info("Starting database search", search_term=message, limit=10)
                search_results = supabase_db.search_services_by_text(message, limit=10)
                logger.info("✓ Database search completed", results_count=len(search_results))
                
                if search_results:
                    first = search_results[0]
                    logger.info("First result:", 
                               service_name=first.get('service_name'),
                               suburb=first.get('suburb'))
                else:
                    logger.warning("⚠ Search returned zero results")
                    
            except Exception as e:
                logger.error("✗ Database search FAILED", error=str(e), exc_info=True)
                return self._error_response(session_id, f"Database search failed: {str(e)}")

            # Generate formatted response
            try:
                if search_results:
                    return await self._generate_success_response(
                        message, search_results, session_id, openai_client
                    )
                else:
                    return await self._generate_no_results_response(
                        message, session_id, openai_client
                    )
                    
            except Exception as e:
                logger.error("✗ Response generation failed", error=str(e), exc_info=True)
                
                # Fallback to manual formatting if AI fails
                if search_results:
                    return self._manual_format_response(search_results, session_id)
                else:
                    return self._error_response(session_id, f"AI service failed: {str(e)}")

        except Exception as e:
            logger.error("✗ CHAT PROCESSING FAILED", error=str(e), exc_info=True)
            return self._error_response(session_id, str(e))

    async def _generate_success_response(
        self, 
        message: str, 
        search_results: List[Dict], 
        session_id: str,
        openai_client
    ) -> Dict[str, Any]:
        """Generate a well-structured response when services are found."""
        
        formatted_services = self._format_services(search_results, limit=5)
        
        # Create a concise summary for the AI to reference
        services_summary = "\n".join([
            f"- {s['name']} ({s['location']}) - {s['cost']}, Phone: {s['phone']}"
            for s in formatted_services
        ])
        
        prompt = f"""The user asked: "{message}"

I found {len(search_results)} mental health services. Here's a summary:
{services_summary}

Provide a brief, warm intro message (max 80 words) that:
1. Acknowledges their search
2. Mentions how many services were found
3. Encourages them to review the services and reach out
4. Is empathetic but concise
5. Reminds them this is supportive assistance, not professional medical advice

Do NOT list the services - just provide a short intro message. The services will be shown separately."""

        response = openai_client.client.chat.completions.create(
            model=self.settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=200
        )
        
        intro_message = response.choices[0].message.content
        
        # Generate helpful next steps
        next_steps = [
            "Review the services listed and choose one that fits your needs",
            "Call the service directly to inquire about appointments",
        ]
        
        # Add cost-specific advice if there are free services
        if any(s.get('cost', '').lower() == 'free' for s in formatted_services):
            next_steps.append("Consider starting with the free services available")
        
        next_steps.extend([
            "Contact your GP for professional advice and referrals",
            "Call Lifeline (13 11 14) or Beyond Blue (1300 22 4636) for immediate support"
        ])
        
        return {
            "intro_message": intro_message,
            "services": formatted_services,
            "services_found": len(search_results),
            "next_steps": next_steps[:4],  # Keep to 4 steps max
            "session_id": session_id,
            "query_successful": True
        }

    async def _generate_no_results_response(
        self, 
        message: str, 
        session_id: str,
        openai_client
    ) -> Dict[str, Any]:
        """Generate response when no services are found."""
        
        prompt = f"""The user asked: "{message}"

No specific services were found matching their search.

Provide a brief, supportive message (max 80 words) that:
1. Acknowledges we couldn't find specific matches
2. Suggests trying different search terms or broader locations
3. Is empathetic and encouraging

Keep it concise and helpful."""

        response = openai_client.client.chat.completions.create(
            model=self.settings.openai_model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=200
        )
        
        return {
            "intro_message": response.choices[0].message.content,
            "services": [],
            "services_found": 0,
            "next_steps": [
                "Try searching with different terms like 'counseling', 'therapy', or 'psychologist'",
                "Expand your search to nearby suburbs or the broader region",
                "Contact your GP for personalized recommendations",
                "Call Lifeline (13 11 14) or Beyond Blue (1300 22 4636) for immediate support"
            ],
            "session_id": session_id,
            "query_successful": True
        }

    def _manual_format_response(self, search_results: List[Dict], session_id: str) -> Dict[str, Any]:
        """Fallback manual formatting if AI fails."""
        formatted_services = self._format_services(search_results)
        
        return {
            "intro_message": f"I found {len(search_results)} mental health services that match your search. Here are the details:",
            "services": formatted_services,
            "services_found": len(search_results),
            "next_steps": [
                "Contact the services directly using the phone numbers provided",
                "Check if they accept new patients and their availability",
                "Ask about wait times and appointment procedures",
                "Speak with your GP for additional guidance"
            ],
            "session_id": session_id,
            "query_successful": True,
            "warning": "AI formatting unavailable - using manual format"
        }

    def _error_response(self, session_id: str, error_message: str) -> Dict[str, Any]:
        """Generate error response."""
        return {
            "intro_message": "I apologise, but I'm experiencing technical difficulties. Please try again later or contact support.",
            "services": [],
            "services_found": 0,
            "next_steps": [
                "Try again in a few minutes",
                "Contact your GP for immediate assistance",
                "Call Lifeline (13 11 14) for mental health support"
            ],
            "session_id": session_id,
            "query_successful": False,
            "error": error_message
        }

    async def get_conversation_history(self, session_id: str, limit: int = 20) -> List[Dict]:
        """Get conversation history for a session."""
        try:
            supabase_db = await get_supabase_db()
            messages = supabase_db.query_table(
                "messages",
                filters={"session_id": session_id},
                limit=limit
            )
            return messages
        except Exception as e:
            logger.error("Failed to get conversation history", error=str(e))
            return []

    async def get_suggested_questions(self) -> List[str]:
        """Get suggested questions to help users get started."""
        return [
            "Find mental health services in Melbourne",
            "What free counseling services are available?",
            "I need help with anxiety - what services can help?",
            "Show me telehealth therapy options",
            "Are there services for young people with depression?",
        ]

    async def health_check(self) -> Dict[str, Any]:
        """Check the health of chat service components."""
        try:
            config_status = {
                "openai_api_key_set": bool(self.settings.openai_api_key),
                "supabase_url_set": bool(self.settings.supabase_url),
                "supabase_key_set": bool(self.settings.supabase_key),
                "openai_model": self.settings.openai_model,
            }
            
            supabase_db = await get_supabase_db()
            db_status = await supabase_db.test_connection()
            
            openai_client = get_openai_client()
            openai_status = await openai_client.test_connection()

            all_healthy = (
                config_status["openai_api_key_set"] and
                config_status["supabase_url_set"] and
                config_status["supabase_key_set"] and
                db_status.get("status") == "connected" and
                openai_status.get("status") == "connected"
            )

            return {
                "status": "healthy" if all_healthy else "degraded",
                "configuration": config_status,
                "database": db_status,
                "openai": openai_status,
                "ready_for_chat": all_healthy,
            }
        except Exception as e:
            logger.error("Chat service health check failed", error=str(e), exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "ready_for_chat": False
            }


chat_service = MentalHealthChatService()

async def get_chat_service() -> MentalHealthChatService:
    return chat_service