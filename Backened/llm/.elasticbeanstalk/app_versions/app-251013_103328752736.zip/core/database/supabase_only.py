"""
Supabase-only connection for mental health services database.
Improved with better error handling and logging.
"""

import json
from typing import Any, Dict, List, Optional
from supabase import create_client, Client
import structlog

from app.config import get_settings

logger = structlog.get_logger(__name__)


class SupabaseOnlyConnection:
    """Manages Supabase client connections for mental health services database."""

    def __init__(self):
        self.settings = get_settings()
        self._client: Optional[Client] = None
        self.table_names = [
            "campus", "cost", "cost_lookup", "delivery_method", "delivery_method_lookup",
            "level_of_care", "level_of_care_lookup", "messages", "organisation", "postcode",
            "referral_pathway", "referral_pathway_lookup", "region", "service", "service_campus",
            "service_region", "service_type", "service_type_lookup", "spatial_ref_sys",
            "staging_services", "target_population", "target_population_lookup",
            "workforce_type", "workforce_type_lookup",
        ]

    @property
    def client(self) -> Client:
        """Get or create Supabase client."""
        if self._client is None:
            url = self.settings.supabase_url
            key = self.settings.supabase_service_key or self.settings.supabase_key
            
            if not url or not key:
                raise ValueError("Supabase URL and KEY must be configured. Set SUPABASE_URL and SUPABASE_KEY environment variables.")
            
            try:
                self._client = create_client(url, key)
                logger.info("Supabase client created successfully", url=url[:30] + "...")
            except Exception as e:
                logger.error("Failed to create Supabase client", error=str(e))
                raise
                
        return self._client

    def query_table(
        self, 
        table_name: str, 
        select: str = "*", 
        filters: Optional[Dict[str, Any]] = None, 
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Query a specific table using Supabase client."""
        try:
            logger.info("Querying table", table=table_name, limit=limit)
            
            query = self.client.table(table_name).select(select)
            
            if filters:
                for key, value in filters.items():
                    query = query.eq(key, value)
                    
            if limit:
                query = query.limit(limit)
                
            result = query.execute()
            
            data = result.data if result.data else []
            logger.info("Query completed", table=table_name, results=len(data))
            
            return data
            
        except Exception as e:
            logger.error("Table query failed", table=table_name, error=str(e), exc_info=True)
            # Re-raise the exception so calling code knows there was an error
            raise Exception(f"Failed to query table {table_name}: {str(e)}")

    def search_services_by_text(self, search_term: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search for services using text search in the staging_services table."""
        try:
            logger.info("Searching for services", search_term=search_term, limit=limit)
            
            if not search_term or not search_term.strip():
                logger.warning("Empty search term provided")
                return []
            
            # Escape any special characters in search term
            search_term = search_term.strip()
            
            # Use ilike for case-insensitive search across multiple fields
            result = self.client.table("staging_services").select("*").or_(
                f"service_name.ilike.%{search_term}%,"
                f"organisation_name.ilike.%{search_term}%,"
                f"suburb.ilike.%{search_term}%,"
                f"address.ilike.%{search_term}%,"
                f"notes.ilike.%{search_term}%,"
                f"service_type.ilike.%{search_term}%,"
                f"state.ilike.%{search_term}%"
            ).limit(limit).execute()
            
            data = result.data if result.data else []
            logger.info("Search completed", search_term=search_term, results=len(data))
            
            if not data:
                logger.warning("No results found for search", search_term=search_term)
            
            return data

        except Exception as e:
            logger.error("Service text search failed", search_term=search_term, error=str(e), exc_info=True)
            # Re-raise with more context
            raise Exception(f"Database search failed for '{search_term}': {str(e)}")

    def get_service_by_id(self, service_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific service by ID."""
        try:
            result = self.client.table("staging_services").select("*").eq("id", service_id).limit(1).execute()
            
            if result.data and len(result.data) > 0:
                return result.data[0]
            return None
            
        except Exception as e:
            logger.error("Failed to get service by ID", service_id=service_id, error=str(e))
            raise Exception(f"Failed to retrieve service {service_id}: {str(e)}")

    def search_by_location(self, suburb: Optional[str] = None, state: Optional[str] = None, postcode: Optional[str] = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Search for services by location."""
        try:
            query = self.client.table("staging_services").select("*")
            
            if suburb:
                query = query.ilike("suburb", f"%{suburb}%")
            if state:
                query = query.ilike("state", f"%{state}%")
            if postcode:
                query = query.eq("postcode", postcode)
            
            result = query.limit(limit).execute()
            return result.data if result.data else []
            
        except Exception as e:
            logger.error("Location search failed", suburb=suburb, state=state, postcode=postcode, error=str(e))
            raise Exception(f"Location search failed: {str(e)}")

    def search_by_cost(self, cost_type: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Search for services by cost type (e.g., 'Free', 'Bulk-billed')."""
        try:
            result = self.client.table("staging_services").select("*").ilike("cost", f"%{cost_type}%").limit(limit).execute()
            return result.data if result.data else []
            
        except Exception as e:
            logger.error("Cost search failed", cost_type=cost_type, error=str(e))
            raise Exception(f"Cost search failed: {str(e)}")

    async def test_connection(self) -> Dict[str, Any]:
        """Test Supabase connection."""
        try:
            # Test if we can create the client
            client = self.client
            
            # Try a simple query to verify connection works
            test_result = client.table("staging_services").select("id").limit(1).execute()
            
            return {
                "status": "connected",
                "connection_type": "supabase_rest_api",
                "client_status": "connected",
                "ready_for_queries": True,
                "test_query_success": True,
                "sample_data_available": bool(test_result.data)
            }
            
        except Exception as e:
            logger.error("Supabase connection test failed", error=str(e), exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "ready_for_queries": False,
                "suggestion": "Check SUPABASE_URL and SUPABASE_KEY environment variables"
            }

    def get_table_sample(self, table_name: str = "staging_services", limit: int = 3) -> List[Dict[str, Any]]:
        """Get a sample of data from a table for debugging."""
        try:
            return self.query_table(table_name, limit=limit)
        except Exception as e:
            logger.error("Failed to get table sample", table=table_name, error=str(e))
            return []


supabase_db = SupabaseOnlyConnection()

async def get_supabase_db() -> SupabaseOnlyConnection:
    return supabase_db