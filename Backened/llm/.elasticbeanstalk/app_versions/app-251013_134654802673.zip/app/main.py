"""
Mental Health LLM Backend - Main FastAPI Application
"""

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from app.config import get_settings
from core.database.supabase_only import get_supabase_db, SupabaseOnlyConnection
from services.chat_service import get_chat_service

settings = get_settings()

app = FastAPI(
    title="Mental Health LLM Backend",
    description="LLM-powered chatbot with database querying for mental health applications",
    version="1.0.0",
    docs_url=f"/docs",
    redoc_url=f"/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://comp-30022-group-30-mental-health-s.vercel.app",
        "https://*.vercel.app",
        "http://localhost:5173",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {
        "message": "Mental Health LLM Backend is running!",
        "environment": settings.environment,
        "chat_available": True,
    }

@app.get("/health")
async def health_check(db: SupabaseOnlyConnection = Depends(get_supabase_db)):
    db_status = await db.test_connection()
    return {
        "status": "healthy",
        "environment": settings.environment,
        "openai_configured": bool(settings.openai_api_key),
        "supabase_configured": bool(settings.supabase_url and settings.supabase_key),
        "database": db_status
    }

class ChatRequest(BaseModel):
    message: str
    session_id: Optional[str] = None

@app.post("/api/v1/chat/chat")
async def chat(request: ChatRequest):
    """Chat endpoint."""
    chat_service = await get_chat_service()
    result = await chat_service.process_message(
        message=request.message,
        session_id=request.session_id
    )
    return result

@app.get("/debug/versions")
async def get_versions():
    import supabase
    import openai
    import fastapi
    try:
        import httpx
        httpx_version = httpx.__version__
    except:
        httpx_version = "not installed"
    
    return {
        "supabase": supabase.__version__ if hasattr(supabase, '__version__') else "unknown",
        "openai": openai.__version__ if hasattr(openai, '__version__') else "unknown", 
        "fastapi": fastapi.__version__ if hasattr(fastapi, '__version__') else "unknown",
        "httpx": httpx_version,
    }

@app.get("/debug/code-version")
async def code_version():
    """Check which version of the code is running"""
    return {
        "timestamp": "2025-10-13-v6",
        "chat_service_file": "updated_with_logging_v2",
        "test": "New code is deployed with chat-debug endpoint"
    }

@app.get("/debug/supabase-test")
async def test_supabase_connection():
    """Test different ways to connect to Supabase"""
    results = {}
    
    # Test 1: Check environment variables
    results["env_vars"] = {
        "SUPABASE_URL": bool(settings.supabase_url),
        "SUPABASE_KEY": bool(settings.supabase_key),
        "url_value": settings.supabase_url[:30] + "..." if settings.supabase_url else None
    }
    
    # Test 2: Try creating client with minimal parameters
    try:
        from supabase import create_client
        test_client = create_client(
            supabase_url=settings.supabase_url,
            supabase_key=settings.supabase_key
        )
        results["client_creation"] = "success"
        
        # Test 3: Try a simple query
        try:
            query_result = test_client.table("staging_services").select("id").limit(1).execute()
            results["query_test"] = {
                "status": "success",
                "has_data": bool(query_result.data)
            }
        except Exception as e:
            results["query_test"] = {
                "status": "error",
                "error": str(e)
            }
            
    except Exception as e:
        results["client_creation"] = {
            "status": "error",
            "error": str(e),
            "error_type": type(e).__name__
        }
    
    return results

@app.get("/debug/test-search")
async def test_search(query: str = "Melbourne"):
    """Test search functionality directly"""
    try:
        from core.database.supabase_only import get_supabase_db
        db = await get_supabase_db()
        
        # Test the search
        results = db.search_services_by_text(query, limit=5)
        
        return {
            "query": query,
            "results_count": len(results),
            "results": results[:2] if results else [],
            "search_worked": len(results) > 0
        }
    except Exception as e:
        return {
            "error": str(e),
            "error_type": type(e).__name__
        }

@app.post("/api/v1/chat/chat-debug")
async def chat_debug(request: ChatRequest):
    """Debug version of chat endpoint - shows what chat service sees"""
    from services.chat_service import get_chat_service
    from core.database.supabase_only import get_supabase_db
    
    # Test 1: Direct database call in this endpoint
    db = await get_supabase_db()
    direct_results = db.search_services_by_text(request.message, limit=5)
    
    # Test 2: Call through chat service
    chat_service = await get_chat_service()
    result = await chat_service.process_message(
        message=request.message,
        session_id=request.session_id
    )
    
    # Return comparison
    return {
        "direct_search_in_endpoint": {
            "count": len(direct_results),
            "sample": direct_results[0] if direct_results else None
        },
        "chat_service_result": result,
        "mismatch": len(direct_results) > 0 and result.get("services_found", 0) == 0
    }

# Add this to your main.py

from fastapi.responses import HTMLResponse

@app.get("/test-chat", response_class=HTMLResponse)
async def test_chat_page():
    """Simple HTML page to test the chatbot"""
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Mental Health Chatbot Test</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 {
                color: #333;
                margin-bottom: 30px;
            }
            .input-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
                color: #555;
            }
            input[type="text"] {
                width: 100%;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                box-sizing: border-box;
            }
            button {
                background-color: #4CAF50;
                color: white;
                padding: 12px 30px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 16px;
                margin-right: 10px;
            }
            button:hover {
                background-color: #45a049;
            }
            button:disabled {
                background-color: #cccccc;
                cursor: not-allowed;
            }
            .example-btn {
                background-color: #008CBA;
                padding: 8px 16px;
                font-size: 14px;
            }
            .example-btn:hover {
                background-color: #007399;
            }
            #loading {
                display: none;
                color: #666;
                font-style: italic;
                margin-top: 10px;
            }
            #result {
                margin-top: 30px;
                padding: 20px;
                background-color: #f9f9f9;
                border-left: 4px solid #4CAF50;
                border-radius: 5px;
                display: none;
            }
            #error {
                margin-top: 30px;
                padding: 20px;
                background-color: #ffebee;
                border-left: 4px solid #f44336;
                border-radius: 5px;
                display: none;
                color: #c62828;
            }
            .response-section {
                margin-bottom: 20px;
            }
            .response-section h3 {
                color: #333;
                margin-bottom: 10px;
                font-size: 18px;
            }
            .service-count {
                font-weight: bold;
                color: #4CAF50;
            }
            .service-item {
                background: white;
                padding: 15px;
                margin: 10px 0;
                border-radius: 5px;
                border: 1px solid #ddd;
            }
            .service-item strong {
                color: #555;
            }
            pre {
                background: #f5f5f5;
                padding: 15px;
                border-radius: 5px;
                overflow-x: auto;
                font-size: 12px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🧠 Mental Health Chatbot Test</h1>
            
            <div class="input-group">
                <label for="message">Enter your message:</label>
                <input type="text" id="message" placeholder="Find mental health services in Melbourne" />
            </div>
            
            <button onclick="sendMessage()">Send Message</button>
            <button class="example-btn" onclick="useExample('Find mental health services in Melbourne')">Example 1</button>
            <button class="example-btn" onclick="useExample('therapy services in Carlton')">Example 2</button>
            <button class="example-btn" onclick="useExample('free counseling')">Example 3</button>
            
            <div id="loading">🔄 Searching for services...</div>
            
            <div id="result">
                <div class="response-section">
                    <h3>Chatbot Response:</h3>
                    <div id="message-response"></div>
                </div>
                
                <div class="response-section">
                    <h3>Search Details:</h3>
                    <p><span class="service-count" id="services-found"></span></p>
                    <p><strong>Session ID:</strong> <span id="session-id"></span></p>
                    <p><strong>Query Successful:</strong> <span id="query-status"></span></p>
                </div>
                
                <div class="response-section" id="services-section" style="display:none;">
                    <h3>Services Found:</h3>
                    <div id="services-list"></div>
                </div>
                
                <div class="response-section">
                    <h3>Raw Response:</h3>
                    <pre id="raw-response"></pre>
                </div>
            </div>
            
            <div id="error"></div>
        </div>

        <script>
            function useExample(text) {
                document.getElementById('message').value = text;
            }

            async function sendMessage() {
                const message = document.getElementById('message').value;
                const loadingEl = document.getElementById('loading');
                const resultEl = document.getElementById('result');
                const errorEl = document.getElementById('error');
                
                if (!message) {
                    alert('Please enter a message');
                    return;
                }
                
                // Show loading
                loadingEl.style.display = 'block';
                resultEl.style.display = 'none';
                errorEl.style.display = 'none';
                
                try {
                    const response = await fetch('/api/v1/chat/chat', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ message: message })
                    });
                    
                    const data = await response.json();
                    
                    // Hide loading
                    loadingEl.style.display = 'none';
                    
                    if (data.query_successful) {
                        // Show result
                        resultEl.style.display = 'block';
                        
                        // Fill in the response
                        document.getElementById('message-response').innerHTML = 
                            data.message.replace(/\n/g, '<br>');
                        document.getElementById('services-found').textContent = 
                            `${data.services_found} services found`;
                        document.getElementById('session-id').textContent = data.session_id;
                        document.getElementById('query-status').textContent = 
                            data.query_successful ? '✅ Yes' : '❌ No';
                        
                        // Show services if available
                        if (data.raw_data && data.raw_data.length > 0) {
                            const servicesSection = document.getElementById('services-section');
                            const servicesList = document.getElementById('services-list');
                            servicesSection.style.display = 'block';
                            
                            servicesList.innerHTML = data.raw_data.map(service => `
                                <div class="service-item">
                                    <strong>Service:</strong> ${service.service_name || 'N/A'}<br>
                                    <strong>Organization:</strong> ${service.organisation_name || 'N/A'}<br>
                                    <strong>Location:</strong> ${service.suburb || 'N/A'}, ${service.state || 'N/A'}<br>
                                    <strong>Cost:</strong> ${service.cost || 'N/A'}<br>
                                    <strong>Phone:</strong> ${service.phone || 'N/A'}<br>
                                    <strong>Delivery:</strong> ${service.delivery_method || 'N/A'}
                                </div>
                            `).join('');
                        } else {
                            document.getElementById('services-section').style.display = 'none';
                        }
                        
                        // Show raw response
                        document.getElementById('raw-response').textContent = 
                            JSON.stringify(data, null, 2);
                    } else {
                        throw new Error(data.error || 'Query failed');
                    }
                    
                } catch (error) {
                    loadingEl.style.display = 'none';
                    errorEl.style.display = 'block';
                    errorEl.innerHTML = `<strong>Error:</strong> ${error.message}`;
                }
            }
            
            // Allow Enter key to submit
            document.getElementById('message').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)