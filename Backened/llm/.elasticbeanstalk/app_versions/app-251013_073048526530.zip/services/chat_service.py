cat > services/chat_service.py << 'EOF'
"""
Main chat service orchestrating mental health chatbot functionality.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid
import structlog

from ..core.database.supabase_only import get_supabase_db
from ..core.llm.openai_client import get_openai_client
from ..app.config import get_settings

logger = structlog.get_logger(__name__)

class MentalHealthChatService:
    """Main service for handling mental health chatbot conversations."""

    def __init__(self):
        self.settings = get_settings()

    async def process_message(
        self,
        message: str,
        session_id: Optional[str] = None,
        user_context: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Process a user message and return a response."""
        try:
            # Generate session ID if not provided
            if not session_id:
                session_id = str(uuid.uuid4())

            logger.info("Processing message", message=message, session_id=session_id)

            # Store user message first
            await self._store_message(session_id, "user", message)

            # Get OpenAI client and database
            openai_client = get_openai_client()
            supabase_db = await get_supabase_db()

            # Search for services
            search_results = supabase_db.search_services_by_text(message, limit=10)

            # Generate response using OpenAI
            if search_results:
                prompt = f"""
The user asked: "{message}"

I found these mental health services:
{search_results[:3]}

Please provide a helpful response that:
1. Answers their question
2. Lists the relevant services with key details
3. Is empathetic and supportive
4. Keeps response under 200 words

Respond as a helpful mental health services assistant.
"""
                response = openai_client.client.chat.completions.create(
                    model=self.settings.openai_model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=self.settings.openai_temperature,
                    max_tokens=self.settings.max_response_tokens
                )
                
                response_text = response.choices[0].message.content
                
                response_data = {
                    "message": response_text,
                    "session_id": session_id,
                    "services_found": len(search_results),
                    "raw_data": search_results[:3],
                    "query_successful": True,
                }
            else:
                # No results
                prompt = f"""
The user asked: "{message}"

I couldn't find specific mental health services matching their request.

Please provide a supportive response that:
1. Acknowledges we couldn't find specific matches
2. Suggests they contact their GP or mental health helplines
3. Is empathetic and helpful
4. Keeps response under 150 words
"""
                response = openai_client.client.chat.completions.create(
                    model=self.settings.openai_model,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=self.settings.openai_temperature,
                    max_tokens=self.settings.max_response_tokens
                )
                
                response_text = response.choices[0].message.content
                
                response_data = {
                    "message": response_text,
                    "session_id": session_id,
                    "services_found": 0,
                    "query_successful": True,
                    "suggestion": "Try different search terms or contact your GP",
                }

            # Store assistant response
            await self._store_message(session_id, "assistant", response_data["message"])

            logger.info(
                "Message processed successfully",
                session_id=session_id,
                successful=response_data["query_successful"],
            )

            return response_data

        except Exception as e:
            logger.error(
                "Chat processing failed", message=message, error=str(e), exc_info=True
            )

            error_response = "I apologize, but I'm experiencing technical difficulties. Please try again later."

            if session_id:
                try:
                    await self._store_message(session_id, "assistant", error_response)
                except:
                    pass

            return {
                "message": error_response,
                "session_id": session_id or str(uuid.uuid4()),
                "services_found": 0,
                "query_successful": False,
                "error": str(e),
            }

    async def _store_message(self, session_id: str, role: str, content: str):
        """Store a message in the database."""
        try:
            supabase_db = await get_supabase_db()

            message_data = {
                "session_id": session_id,
                "role": role,
                "content": content,
                "created_at": datetime.now().isoformat(),
            }

            result = supabase_db.client.table("messages").insert(message_data).execute()

            if result.data:
                logger.debug(
                    "Message stored successfully", session_id=session_id, role=role
                )
            else:
                logger.warning(
                    "Message storage returned no data", session_id=session_id
                )

        except Exception as e:
            logger.warning(
                "Failed to store message (non-critical)",
                session_id=session_id,
                role=role,
                error=str(e),
            )

    async def get_conversation_history(
        self, session_id: str, limit: int = 20
    ) -> List[Dict[str, Any]]:
        """Retrieve conversation history for a session."""
        try:
            supabase_db = await get_supabase_db()

            messages = supabase_db.query_table(
                "messages",
                select="role,content,created_at",
                filters={"session_id": session_id},
                limit=limit,
            )

            messages.sort(key=lambda x: x.get("created_at", ""))

            return messages

        except Exception as e:
            logger.error(
                "Failed to get conversation history",
                session_id=session_id,
                error=str(e),
            )
            return []

    async def get_suggested_questions(self) -> List[str]:
        """Get suggested questions to help users get started."""
        return [
            "Find mental health services near me in Melbourne",
            "What free counseling services are available?",
            "I need help with anxiety - what services can help?",
            "Show me telehealth therapy options",
            "What are the costs for psychology services?",
            "Find crisis support services",
            "I need a referral - what services accept GP referrals?",
            "What services are available for young people?",
        ]

    async def health_check(self) -> Dict[str, Any]:
        """Check the health of chat service components."""
        try:
            supabase_db = await get_supabase_db()
            db_status = await supabase_db.test_connection()
            
            openai_client = get_openai_client()
            openai_status = await openai_client.test_connection()

            return {
                "status": "healthy" if db_status.get("status") == "connected" and openai_status.get("status") == "connected" else "degraded",
                "database": db_status,
                "openai": openai_status,
                "ready_for_chat": True,
            }

        except Exception as e:
            logger.error("Chat service health check failed", error=str(e))
            return {"status": "error", "error": str(e), "ready_for_chat": False}


# Global chat service instance
chat_service = MentalHealthChatService()


async def get_chat_service() -> MentalHealthChatService:
    """Dependency to get chat service."""
    return chat_service
EOF